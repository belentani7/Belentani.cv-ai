import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export const runtime = 'nodejs';
export const maxDuration = 60;

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface ChatRequest {
  messages: ChatMessage[];
  language?: string;
  context?: string;
}

const LANG_INSTRUCTIONS: Record<string, string> = {
  es: 'Responde SIEMPRE en español de España, con lenguaje sencillo y claro.',
  en: 'Always respond in English, with simple and clear language.',
  ca: 'Respon SEMPRE en català, amb llenguatge senzill i clar.',
  'pt-BR': 'Responda SEMPRE em português brasileiro, com linguagem simples e clara.',
  pt: 'Responda SEMPRE em português, com linguagem simples e clara.',
  fr: 'Réponds TOUJOURS en français, avec un langage simple et clair.',
  ar: 'أجب دائماً بالعربية، بلغة بسيطة وواضحة.',
  zh: '始终用中文回答，语言简单清晰。',
  hi: 'हमेशा हिंदी में उत्तर दें, सरल और स्पष्ट भाषा में।',
  qu: 'Runa Simillapi rimspaña, suti llamiywan.',
  ro: 'Răspunde ÎNTOTDEAUNA în română, cu limbaj simplu și clar.',
  uk: 'Завжди відповідай українською мовою, простою та зрозумілою мовою.',
  ru: 'Всегда отвечай на русском языке, простым и понятным языком.',
  de: 'Antworte IMMER auf Deutsch, mit einfacher und klarer Sprache.',
  it: 'Rispondi SEMPRE in italiano, con linguaggio semplice e chiaro.',
  pl: 'Odpowiadaj ZAWSZE po polsku, prostym i jasnym językiem.',
  tr: 'Her ZAMAN Türkçe yanıt ver, basit ve net bir dille.',
  ur: 'ہمیشہ اردو میں جواب دیں، آسان اور واضح زبان میں۔',
  fa: 'همیشه به فارسی پاسخ دهید، با زبان ساده و واضح.',
  bn: 'সর্বদা বাংলায় উত্তর দিন, সহজ এবং পরিষ্কার ভাষায়।',
  pa: 'ਹਮੇਸ਼ਾ ਪੰਜਾਬੀ ਵਿੱਚ ਜਵਾਬ ਦਿਓ, ਸਧਾਰਨ ਅਤੇ ਸਪਸ਼ਟ ਭਾਸ਼ਾ ਵਿੱਚ।',
  ta: 'எப்போதும் தமிழில் பதிலளிக்கவும், எளிய மற்றும் தெளிவான மொழியில்.',
  te: 'ఎల్లప్పుడూ తెలుగులో సమాధానం ఇవ్వండి, సరళమైన మరియు స్పష్టమైన భాషలో.',
  mr: 'नेहमी मराठीत उत्तर द्या, सोप्या आणि स्पष्ट भाषेत.',
  gu: 'હંમેશા ગુજરાતીમાં જવાબ આપો, સરળ અને સ્પષ્ટ ભાષામાં.',
  sw: 'Jibu kwa Kiswahili kila wakati, kwa lugha rahisi na wazi.',
  am: 'ሁሌም በአማርኛ ይመልሱ፣ በቀላል እና ግልጽ ቋንቋ።',
  tl: 'Palaging sumagot sa Tagalog, sa simpleng at malinaw na wika.',
  vi: 'Luôn trả lời bằng tiếng Việt, với ngôn ngữ đơn giản và rõ ràng.',
  ja: '常に日本語で答えてください。シンプルで明確な言葉で。',
  ko: '항상 한국어로 답변하세요. 간단하고 명확한 언어로.',
};

const SYSTEM_PROMPT = `Eres el asistente virtual de "Manos Abiertas", una plataforma gratuita para personas inmigrantes en España.

Tu propósito: ayudar a personas inmigrantes a:
1. Aprender a usar inteligencia artificial (ChatGPT, Gemini, Copilot, DeepSeek, etc.)
2. Crear su currículum vitae (CV)
3. Conocer sus derechos y los recursos disponibles en España
4. Sobrevivir y integrarse en la sociedad española

CARACTERÍSTICAS DEL PÚBLICO:
- Personas adultas, muchas mayores, con baja alfabetización digital
- Hablan diversos idiomas (la plataforma soporta 39)
- Recién llegadas a España o en proceso de integración
- Muchas solo saben usar WhatsApp y Google

INSTRUCCIONES:
- Sé cálido, amable y paciente. Trata al usuario con dignidad.
- Usa lenguaje sencillo, sin tecnicismos. Si usas una palabra técnica, explícala.
- Da respuestas breves y accionables (máximo 3-4 párrafos).
- Cuando sea relevante, menciona que en la web hay cursos, recursos o secciones específicas.
- Para temas legales, recomienda SIEMPRE consultar con un abogado o la fuente oficial.
- Para emergencias, recomienda llamar al 112 (gratis, 24h, multilingüe).
- NO inventes datos específicos (cantías de ayudas, teléfonos) si no estás seguro. Di "consulta la sección Derechos y Ayudas para datos verificados".
- Si preguntan por NIE, extranjería, asilo, etc., sugiere la sección "Derechos y Ayudas".
- Si preguntan por empleo o CV, sugiere la sección "Crea tu CV".
- Si preguntan por IA, sugiere la sección "Aprende IA".

Eres parte de una plataforma con:
- 8 cursos de IA (ChatGPT, Gemini, Copilot, Claude, DeepSeek, Qwen, Perplexity, Meta AI)
- Constructor de CV con IA
- Curso completo de Office (Word, Excel, PowerPoint)
- 3.647 recursos verificados
- 61 artículos sobre derechos
- 41 contactos de emergencia`;

export async function POST(req: NextRequest) {
  try {
    const body: ChatRequest = await req.json();
    const lang = body.language || 'es';
    const langInstruction = LANG_INSTRUCTIONS[lang] || LANG_INSTRUCTIONS.es;

    const zai = await ZAI.create();

    const messages = [
      { role: 'system' as const, content: `${SYSTEM_PROMPT}\n\n${langInstruction}` },
      ...body.messages.slice(-10), // Keep last 10 messages for context
    ];

    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: 'disabled' },
    });

    const text = completion.choices[0]?.message?.content?.trim() || '';

    return NextResponse.json({ text, ok: true });
  } catch (error: unknown) {
    console.error('Chat API error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json(
      { ok: false, error: message, text: 'Lo siento, tuve un problema. Inténtalo de nuevo.' },
      { status: 500 }
    );
  }
}
